﻿
namespace Exceptions
{
    public class IncorrectDeliveryAddressException : MyExceptions
    {
        public IncorrectDeliveryAddressException(string errorMessage) : base(errorMessage) { }
    }
}

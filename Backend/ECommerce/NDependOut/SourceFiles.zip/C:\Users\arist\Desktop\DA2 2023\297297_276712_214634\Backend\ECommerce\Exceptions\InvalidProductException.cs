﻿
namespace Exceptions
{
    public class InvalidProductException : MyExceptions
    {
        public InvalidProductException(string errorMessage) : base(errorMessage) { }

    }
}

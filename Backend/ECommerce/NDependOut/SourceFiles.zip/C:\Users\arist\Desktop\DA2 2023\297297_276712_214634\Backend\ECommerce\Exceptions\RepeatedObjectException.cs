﻿
namespace Exceptions
{
    public class RepeatedObjectException : MyExceptions
    {
        public RepeatedObjectException(string errorMessage) : base(errorMessage) { }
    }
}

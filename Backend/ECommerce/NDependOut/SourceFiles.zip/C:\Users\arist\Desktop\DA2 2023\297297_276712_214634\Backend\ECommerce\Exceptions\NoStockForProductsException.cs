﻿
namespace Exceptions
{
    public class NoStockForProductsException : MyExceptions
    {
        public NoStockForProductsException(string errorMessage) : base(errorMessage) { }

    }
}

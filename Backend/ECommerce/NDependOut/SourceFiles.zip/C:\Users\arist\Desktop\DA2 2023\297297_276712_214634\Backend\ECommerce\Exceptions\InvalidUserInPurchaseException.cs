﻿
namespace Exceptions
{
    public class InvalidUserInPurchaseException : MyExceptions
    {
        public InvalidUserInPurchaseException(string errorMessage) : base(errorMessage) { }

    }
}

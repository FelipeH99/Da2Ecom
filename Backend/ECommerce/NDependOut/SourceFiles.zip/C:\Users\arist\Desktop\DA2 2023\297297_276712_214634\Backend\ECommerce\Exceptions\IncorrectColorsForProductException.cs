﻿
namespace Exceptions
{
    public class IncorrectColorsForProductException : MyExceptions
    {
        public IncorrectColorsForProductException(string errorMessage) : base(errorMessage) { }

    }
}

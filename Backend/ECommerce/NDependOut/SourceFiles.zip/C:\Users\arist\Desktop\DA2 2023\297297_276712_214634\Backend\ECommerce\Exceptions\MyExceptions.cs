﻿namespace Exceptions
{
    public class MyExceptions : Exception
    {
        public MyExceptions(String message) : base(message) { }

    }
}
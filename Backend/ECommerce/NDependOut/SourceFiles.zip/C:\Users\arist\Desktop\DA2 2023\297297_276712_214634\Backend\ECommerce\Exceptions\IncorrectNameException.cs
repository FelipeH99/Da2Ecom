﻿
namespace Exceptions
{
    public class IncorrectNameException : MyExceptions
    {
        public IncorrectNameException(string errorMessage) : base(errorMessage) { }

    }
}

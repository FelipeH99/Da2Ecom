﻿
namespace Exceptions
{
    public class IncorrectProductsForPurchaseException : MyExceptions
    {
        public IncorrectProductsForPurchaseException(string errorMessage) : base(errorMessage) { }

    }
}

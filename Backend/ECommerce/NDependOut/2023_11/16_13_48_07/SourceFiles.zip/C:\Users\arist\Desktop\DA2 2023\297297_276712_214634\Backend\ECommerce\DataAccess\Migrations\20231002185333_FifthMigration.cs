﻿using Microsoft.EntityFrameworkCore.Migrations;
using System.Diagnostics.CodeAnalysis;

#nullable disable

namespace DataAccess.Migrations
{
    /// <inheritdoc />
    [ExcludeFromCodeCoverage]
    public partial class FifthMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Price",
                table: "Purchase",
                newName: "ProductsPrice");

            migrationBuilder.RenameColumn(
                name: "ItemToBeDiscounted",
                table: "ColorDiscounts",
                newName: "ProductToBeDiscounted");

            migrationBuilder.AddColumn<double>(
                name: "FinalPrice",
                table: "Purchase",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        /// <inheritdoc />
        [ExcludeFromCodeCoverage]
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FinalPrice",
                table: "Purchase");

            migrationBuilder.RenameColumn(
                name: "ProductsPrice",
                table: "Purchase",
                newName: "Price");

            migrationBuilder.RenameColumn(
                name: "ProductToBeDiscounted",
                table: "ColorDiscounts",
                newName: "ItemToBeDiscounted");
        }
    }
}

﻿
namespace Exceptions
{
    public class IncorrectEmailException : MyExceptions
    {
        public IncorrectEmailException(string errorMessage) : base(errorMessage) { }
    }
}

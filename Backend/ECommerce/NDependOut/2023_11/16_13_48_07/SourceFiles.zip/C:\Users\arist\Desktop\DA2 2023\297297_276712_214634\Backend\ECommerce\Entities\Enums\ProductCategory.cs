﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Enums
{
    public enum ProductCategory
    {
        Abrigos,
        Cazadoras,
        Chalecos,
        Trajes,
        Blazers,
        Camisas,
        Camisetas,
        Polos,
        Sudaderas,
        Chandal,
        Punto,
        Pantalon,
        Jeans,
        Bermuda, 
        Zapatos,
        Bolsos,
        Accesorios
    }
}

﻿
namespace Exceptions
{
    public class IncorrectBrandForDiscount : MyExceptions
    {
        public IncorrectBrandForDiscount(string errorMessage) : base(errorMessage) { }

    }
}

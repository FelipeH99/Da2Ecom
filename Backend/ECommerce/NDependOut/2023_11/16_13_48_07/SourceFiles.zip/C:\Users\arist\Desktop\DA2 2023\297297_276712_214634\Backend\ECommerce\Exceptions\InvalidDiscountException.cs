﻿
namespace Exceptions
{
    public class InvalidDiscountException : MyExceptions
    {
        public InvalidDiscountException(string errorMessage) : base(errorMessage) { }

    }
}

﻿
namespace Exceptions
{
    public class InvalidPurchaseException : MyExceptions
    {
        public InvalidPurchaseException(string errorMessage) : base(errorMessage) { }

    }
}

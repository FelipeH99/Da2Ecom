﻿
namespace Exceptions
{
    public class IncorrectColorForDiscount : MyExceptions
    {
        public IncorrectColorForDiscount(string errorMessage) : base(errorMessage) { }

    }
}

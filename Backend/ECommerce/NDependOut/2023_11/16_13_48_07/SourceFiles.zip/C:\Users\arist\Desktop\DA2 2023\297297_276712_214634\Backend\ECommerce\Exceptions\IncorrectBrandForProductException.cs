﻿
namespace Exceptions
{
    public class IncorrectBrandForProductException : MyExceptions
    {
        public IncorrectBrandForProductException(string errorMessage) : base(errorMessage) { }
    }
}

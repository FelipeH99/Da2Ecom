﻿
namespace Exceptions
{
    public class IncorrectPasswordException : MyExceptions
    {
        public IncorrectPasswordException(string errorMessage) : base(errorMessage) { }

    }
}
